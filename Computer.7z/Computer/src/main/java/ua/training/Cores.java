package main.java.ua.training;

public enum Cores {
    ONE, TWO, THREE, FOUR;
}
